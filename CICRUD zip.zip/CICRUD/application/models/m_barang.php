<?php
    class m_barang extends CI_Model{
                                                            
        public function tampil(){
            $query = $this->db->get('tblbarang');
            $data=$query->result_array();
            return $data;
        }

        public function save($barang,$harga,$stock){
                $data = array(
                'nama_barang' => $barang,
                'harga' => $harga,
				'stock' => $stock
        );
        
        $this->db->insert('tblbarang', $data);
    }

    public function pilih_barang($id){
    $query = $this->db->get_where('tblbarang', array('id_barang' => $id));
    return $query;
    }

	public function edit($id,$barang,$harga,$stock){
		    $data = array(
			'nama_barang' => $barang,
			'harga' => $harga,
			'stock' => $stock
	        );
	
	$this->db->where('id_barang', $id);
	$this->db->update('tblbarang', $data);
	}

	public function delete($id){
		$this->db->where('id_barang', $id);
		$this->db->delete('tblbarang');

	}



        
    }
?>
