<?php
class barang extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('m_barang');
    }                                                  

public function index(){
    $data['judul']="data barang";
    $data['barang']=$this->m_barang->tampil();
    $this->load->view('template/header',$data);
    $this->load->view('barang/view_data',$data);
    $this->load->view('template/footer');
}

public function select(){
   
    $data['judul']="data barang";
    $data['barang']=$this->m_barang->tampil();
    $this->load->view('template/header',$data);
    $this->load->view('barang/view_data',$data);
    $this->load->view('template/footer');
}

public function tambah(){
    $data['judul']="tambah data barang";
    $this->load->view('template/header',$data);
    $this->load->view('barang/form_tambah');
    $this->load->view('template/footer');
}

public function insert(){
    $barang=$this->input->post('barang');
    $harga=$this->input->post('harga');
	$stock=$this->input->post('stock');
    echo $barang.$harga.$stock;
    $this->m_barang->save($barang,$harga,$stock);
    redirect('barang');
}

public function get_edit(){
	$id=$this->uri->segment(3);
    //echo "$id";
	$hasil=$this->m_barang->pilih_barang($id);
	$i=$hasil->row_array();
    $data = array(
		'nama_barang' => $i['nama_barang'],
		'harga' => $i['harga'],
		'stock' => $i['stock'],
		'id_barang' => $i['id_barang']
    );

	$data['judul']="ubah data barang";
    $this->load->view('template/header',$data);
    $this->load->view('barang/form_ubah',$data);
    $this->load->view('template/footer');
    
}

public function update(){
	$id=$this->input->post('id_barang');
	$barang=$this->input->post('barang');
    $harga=$this->input->post('harga');
	$stock=$this->input->post('stock');
    //echo"$id.$alamat.$barang";
	
    $this->m_barang->edit($id,$barang,$harga,$stock);
    redirect('barang');

}
public function hapus(){
    $id=$this->uri->segment(3);
	//echo"hapus".$id;
	$this->m_barang->delete($id);
    redirect('barang');

}
}

?>
