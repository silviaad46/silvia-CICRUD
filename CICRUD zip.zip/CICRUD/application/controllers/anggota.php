<?php
class anggota extends CI_Controller{

    public function __construct(){
        parent::__construct();
        $this->load->model('m_anggota');
    }                                                  

public function index(){
    $data['judul']="data anggota perpustakaan";
    $data['anggota']=$this->m_anggota->tampil();
    $this->load->view('template/header',$data);
    $this->load->view('anggota/view_data',$data);
    $this->load->view('template/footer');
}

public function select(){
   
    $data['judul']="data anggota perpustakaan";
    $data['anggota']=$this->m_anggota->tampil();
    $this->load->view('template/header',$data);
    $this->load->view('anggota/view_data',$data);
    $this->load->view('template/footer');
}

public function tambah(){
    $data['judul']="tambah data anggota perpustakaan";
    $this->load->view('template/header',$data);
    $this->load->view('anggota/form_tambah');
    $this->load->view('template/footer');
}

public function insert(){
    $anggota=$this->input->post('anggota');
    $alamat=$this->input->post('alamat');
    echo $anggota.$alamat;
    $this->m_anggota->save($anggota,$alamat);
    redirect('anggota');
}

public function get_edit(){
	$id=$this->uri->segment(3);
    //echo "$id";
	$hasil=$this->m_anggota->pilih_anggota($id);
	$i=$hasil->row_array();
    $data = array(
		'anggota' => $i['anggota'],
		'alamat' => $i['alamat'],
		'idanggota' => $i['idanggota']
    );

	$data['judul']="ubah data anggota perpustakaan";
    $this->load->view('template/header',$data);
    $this->load->view('anggota/form_ubah',$data);
    $this->load->view('template/footer');
    
}

public function update(){
	$id=$this->input->post('idanggota');
	$anggota=$this->input->post('anggota');
    $alamat=$this->input->post('alamat');
    //echo"$id.$alamat.$anggota";
	
    $this->m_anggota->edit($id,$anggota,$alamat);
    redirect('anggota');

}
public function hapus(){
    $id=$this->uri->segment(3);
	//echo"hapus".$id;
	$this->m_anggota->delete($id);
    redirect('anggota');

}
}

?>
