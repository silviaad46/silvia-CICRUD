<html>
    <head>

    <title>belajar mvc di codeigniter</title>
</head>
<body>
    <h1><?php echo $judul?></h1>

 