<a href="<?php echo base_url('anggota/tambah');?>"> tambah anggota baru</a>

<table border="1">
    <th>anggota</th>
    <th>alamat</th>
	<th>ubah</th>
    <th>hapus</th>
    <?php foreach ($anggota as $a): ?>
        <tr>
        <td><?php echo $a['anggota']?></td>
        <td><?php echo $a['alamat']?></td>
        <td><a href="<?php echo site_url('anggota/get_edit/'.$a['idanggota']);?>">ubah</a></td>
		<td><a href="<?php echo site_url('anggota/hapus/'.$a['idanggota']);?>">hapus</a></td>
        
    </tr>
<?php endforeach;?>


</table>
