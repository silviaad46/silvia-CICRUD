<form action="<?php echo base_url('barang/insert');?>" method="post">
    <label>nama barang</label>
    <input type="text" name="barang"> 
    <br>
    <label>harga</label>
    <input type="text" name="harga"> 
    <br>
	<label>stock</label>
    <input type="text" name="stock"> 
    <br>
    <input type="submit" name="simpan" value="simpan"> 
</form>
