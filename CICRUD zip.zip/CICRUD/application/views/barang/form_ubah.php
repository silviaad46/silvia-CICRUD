<form action="<?php echo base_url('barang/update');?>" method="post">
    <label>nama barang</label>
    <input type="text" name="barang" value="<?php echo $nama_barang?>"> 
	<input type="hidden" name="id_barang" value="<?php echo $id_barang?>">
    <br>
    <label>harga</label>
    <input type="text" name="harga" value="<?php echo $harga?>"> 
    <br>
	<label>stock</label>
    <input type="text" name="stock" value="<?php echo $stock?>"> 
    <br>
    <input type="submit" name="simpan" value="simpan"> 
</form>
