<a href="<?php echo base_url('barang/tambah');?>"> tambah barang baru</a>

<table border="1">
    <th>nama barang</th>
    <th>harga</th>
	<th>stock</th>
	<th>ubah</th>
    <th>hapus</th>
    <?php foreach ($barang as $a): ?>
        <tr>
        <td><?php echo $a['nama_barang']?></td>
        <td><?php echo $a['harga']?></td>
		<td><?php echo $a['stock']?></td>
        <td><a href="<?php echo site_url('barang/get_edit/'.$a['id_barang']);?>">ubah</a></td>
		<td><a href="<?php echo site_url('barang/hapus/'.$a['id_barang']);?>">hapus</a></td>
        
    </tr>
<?php endforeach;?>


</table>
